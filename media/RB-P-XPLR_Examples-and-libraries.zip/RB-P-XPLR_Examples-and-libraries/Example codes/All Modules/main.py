# Joy-IT RB-P-XPLR

# Load libraries
from machine import Pin, PWM
from utime import sleep
from neopixel import NeoPixel
from dht import DHT11
import lcd_gfx
import ST7735

buzzerPin = Pin(27)
relayPin = 28
ledPin = 1
ledCount = 4
dhtPin = 0
buttons = [10, 11, 14, 15]
lcdLightPin = 2
servoOnePin = 7
servoTwoPin = 8
servoThreePin = 9
servoFourPin = 20
interfaceOnePin = 21
interfaceTwoPin = 22
interfaceThreePin = 26

# Initialize GPIOs
led = Pin(ledPin, Pin.OUT)
buzzer = PWM(buzzerPin)
relay = Pin(relayPin, Pin.OUT)
led = NeoPixel(Pin(ledPin, Pin.OUT), ledCount)
dht = DHT11(Pin(dhtPin, Pin.IN))
buttonOne = Pin(buttons[0], Pin.IN, Pin.PULL_DOWN)
buttonTwo = Pin(buttons[1], Pin.IN, Pin.PULL_DOWN)
buttonThree = Pin(buttons[2], Pin.IN, Pin.PULL_DOWN)
buttonFour = Pin(buttons[3], Pin.IN, Pin.PULL_DOWN)
backlight = Pin(lcdLightPin, Pin.OUT)
servoOne = PWM(Pin(servoOnePin))
servoTwo = PWM(Pin(servoTwoPin))
servoThree = PWM(Pin(servoThreePin))
servoFour = PWM(Pin(servoFourPin))
interfaceOne = Pin(interfaceOnePin, Pin.OUT)
interfaceTwo = Pin(interfaceTwoPin, Pin.OUT)
interfaceThree = Pin(interfaceThreePin, Pin.OUT)

# Set PWM frequency to 50 Hz for all servos
servoOne.freq(50)
servoTwo.freq(50)
servoThree.freq(50)
servoFour.freq(50)

# Servo degree positions in nanoseconds
deg0 = 500000    # 0.5 ms
deg45 = 1000000  # 1.0 ms
deg90 = 1500000  # 1.5 ms
deg135 = 2000000 # 2.0 ms
deg180 = 2500000 # 2.5 ms
# Initialize LCD
spi = machine.SPI(0, baudrate=8000000, polarity=0, phase=0, sck=Pin(18), mosi=Pin(19), miso=Pin(16))
lcd = ST7735.ST7735(spi, rst=6, ce=17, dc=3)


#button functions
def buttonUp(pin):
    # Turn LEDs white
    for i in range (ledCount):
        led[i] = (255, 255, 255)
        led.write()

def buttonRight(pin):
    # Turn LEDs red
    for i in range (ledCount):
        led[i] = (255, 0, 0)
        led.write()

def buttonDown(pin):
    # Turn LEDs off
    for i in range (ledCount):
        led[i] = (0, 0, 0)
        led.write()

def buttonLeft(pin):
    # Turn LEDs blue
    for i in range (ledCount):
        led[i] = (0, 0, 255)
        led.write()
    
    
    # Toggle LEDs
    #all leds green
    for i in range (ledCount):
        led[i] = (255, 255, 255)
        led.write()
        
    #all leds red 
    for i in range (ledCount):
        led[i] = (0, 255, 0)
        led.write()
        sleep(0.5)
    
    #all leds blue
    for i in range (ledCount):
        led[i] = (0, 0, 255)
        led.write()
        sleep(0.5)
        
    #turn off all leds  
    for i in range (ledCount):
        led[i] = (0, 0, 0)
        led.write()
        sleep(1)
        
#setting interrupts for the buttons
buttonOne.irq(trigger=Pin.IRQ_RISING, handler=buttonUp)
buttonTwo.irq(trigger=Pin.IRQ_RISING, handler=buttonRight)
buttonThree.irq(trigger=Pin.IRQ_RISING, handler=buttonDown)
buttonFour.irq(trigger=Pin.IRQ_RISING, handler=buttonLeft)


# Testing the TFT
#turn backlight on
backlight.high() 
lcd.reset()
lcd.begin()
#turn screen green
lcd.fill_screen(lcd.rgb_to_565(0,255,0))




while True:
    # Measure DHT11 values
    dht.measure()
    temp = dht.temperature()
    humid = dht.humidity()
    
    # Write measurements to screen
    lcd.p_string(20,50,'Temp.: ' + str(temp))
    lcd.p_string(20,80,'Humid.: ' + str(humid))
    
    # toggle Interface pins
    interfaceOne.high()
    interfaceTwo.high()
    interfaceThree.high()
    sleep(1)
    interfaceOne.low()
    interfaceTwo.low()
    interfaceThree.low()
    
    
    # Activate buzzer for 1 sec
    buzzer.freq(1000)
    buzzer.duty_u16(1000)
    sleep(1)
    buzzer.duty_u16(0)

    # All LEDs white
    led[0] = (255, 255, 255)
    led[1] = (255, 255, 255)
    led[2] = (255, 255, 255)
    led[3] = (255, 255, 255)
    led.write()
    
    # Turn all servos
    servoOne.duty_ns(deg0)
    servoTwo.duty_ns(deg0)
    servoThree.duty_ns(deg0)
    servoFour.duty_ns(deg0)
    sleep(1)
    servoOne.duty_ns(deg45)
    servoTwo.duty_ns(deg45)
    servoThree.duty_ns(deg45)
    servoFour.duty_ns(deg45)
    sleep(1)
    servoOne.duty_ns(deg90)
    servoTwo.duty_ns(deg90)
    servoThree.duty_ns(deg90)
    servoFour.duty_ns(deg90)
    sleep(1)
    servoOne.duty_ns(deg135)
    servoTwo.duty_ns(deg135)
    servoThree.duty_ns(deg135)
    servoFour.duty_ns(deg135)
    sleep(1)
    servoOne.duty_ns(deg180)
    servoTwo.duty_ns(deg180)
    servoThree.duty_ns(deg180)
    servoFour.duty_ns(deg180)
    sleep(1)
    
    # Toggle Relay
    relay.on()
    sleep(1)
    relay.off()
    sleep(1)
